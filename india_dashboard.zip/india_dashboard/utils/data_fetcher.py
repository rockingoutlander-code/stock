"""
utils/data_fetcher.py
=====================
Live market data fetcher for India Daily Invest Dashboard.

Supported providers:
  1. Yahoo Finance  — Free, no API key needed  (default)
  2. Zerodha Kite   — Real-time NSE/BSE, requires API key
  3. Upstox         — Real-time NSE/BSE, requires API key
  4. Alpha Vantage  — Delayed 15 min, free tier available

Configure your provider in the PROVIDER constant below.
"""

import os
import requests
import pandas as pd
from datetime import datetime, timedelta
from functools import lru_cache

# ── Choose your provider ─────────────────────────────────────────────────────
PROVIDER = "yahoo"          # "yahoo" | "zerodha" | "upstox" | "alphavantage"

# ── API Keys (set as env vars or paste directly for testing) ─────────────────
ZERODHA_API_KEY      = os.getenv("ZERODHA_API_KEY", "YOUR_KEY_HERE")
ZERODHA_ACCESS_TOKEN = os.getenv("ZERODHA_ACCESS_TOKEN", "YOUR_TOKEN_HERE")
UPSTOX_API_KEY       = os.getenv("UPSTOX_API_KEY", "YOUR_KEY_HERE")
ALPHAVANTAGE_API_KEY = os.getenv("ALPHAVANTAGE_KEY", "YOUR_KEY_HERE")

# ── NSE symbol → Yahoo Finance suffix map ────────────────────────────────────
YAHOO_SUFFIX = ".NS"   # NSE stocks
# YAHOO_SUFFIX = ".BO"   # BSE stocks


# ════════════════════════════════════════════════════════════════════════════
#  YAHOO FINANCE  (free, no key, ~15min delay)
# ════════════════════════════════════════════════════════════════════════════

def get_quote_yahoo(symbol: str) -> dict:
    """
    Fetch live quote from Yahoo Finance.
    symbol: NSE symbol e.g. "BEL", "NESTLEIND", "HDFCBANK"
    """
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}{YAHOO_SUFFIX}"
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        r = requests.get(url, headers=headers, timeout=8)
        r.raise_for_status()
        data = r.json()["chart"]["result"][0]
        meta = data["meta"]
        return {
            "symbol":    symbol,
            "name":      meta.get("longName", symbol),
            "cmp":       round(meta["regularMarketPrice"], 2),
            "prev_close":round(meta["chartPreviousClose"], 2),
            "change":    round(meta["regularMarketPrice"] - meta["chartPreviousClose"], 2),
            "change_pct":round((meta["regularMarketPrice"] - meta["chartPreviousClose"]) / meta["chartPreviousClose"] * 100, 2),
            "52w_high":  round(meta.get("fiftyTwoWeekHigh", 0), 2),
            "52w_low":   round(meta.get("fiftyTwoWeekLow", 0), 2),
            "volume":    meta.get("regularMarketVolume", 0),
        }
    except Exception as e:
        return {"symbol": symbol, "error": str(e)}


def get_history_yahoo(symbol: str, period: str = "6mo") -> pd.DataFrame:
    """
    Fetch OHLCV history from Yahoo Finance.
    period options: 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
    Returns DataFrame with columns: Date, Open, High, Low, Close, Volume
    """
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}{YAHOO_SUFFIX}"
    params = {"range": period, "interval": "1d"}
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        r = requests.get(url, headers=headers, params=params, timeout=10)
        r.raise_for_status()
        data   = r.json()["chart"]["result"][0]
        ts     = data["timestamp"]
        ohlcv  = data["indicators"]["quote"][0]
        df = pd.DataFrame({
            "Date":   pd.to_datetime(ts, unit="s").normalize(),
            "Open":   ohlcv["open"],
            "High":   ohlcv["high"],
            "Low":    ohlcv["low"],
            "Close":  ohlcv["close"],
            "Volume": ohlcv["volume"],
        }).dropna()
        return df
    except Exception as e:
        return pd.DataFrame()


def get_nifty50_yahoo() -> dict:
    return get_quote_yahoo("^NSEI")

def get_banknifty_yahoo() -> dict:
    return get_quote_yahoo("^NSEBANK")

def get_india_vix_yahoo() -> dict:
    return get_quote_yahoo("^INDIAVIX")


# ════════════════════════════════════════════════════════════════════════════
#  ZERODHA KITE  (real-time, requires API key + login token)
# ════════════════════════════════════════════════════════════════════════════

def get_quote_zerodha(instrument_token: int) -> dict:
    """
    Fetch live quote via Zerodha Kite API.

    Steps to get access_token:
      1. Register at https://kite.trade and create an app
      2. Login flow: https://kite.trade/connect/login?api_key=YOUR_KEY
      3. Exchange the request_token for access_token (done once per session)
      4. Paste access_token in ZERODHA_ACCESS_TOKEN env var

    instrument_token examples (NSE):
      NIFTY 50  → 256265
      HDFCBANK  → 341249
      BEL       → 1067289
      NESTLEIND → 4931073
    """
    url     = f"https://api.kite.trade/quote"
    headers = {
        "X-Kite-Version": "3",
        "Authorization":  f"token {ZERODHA_API_KEY}:{ZERODHA_ACCESS_TOKEN}",
    }
    params = {"i": f"NSE:{instrument_token}"}
    try:
        r    = requests.get(url, headers=headers, params=params, timeout=8)
        r.raise_for_status()
        data = r.json()["data"]
        key  = list(data.keys())[0]
        q    = data[key]
        return {
            "cmp":    q["last_price"],
            "change": q["net_change"],
            "volume": q["volume"],
            "ohlc":   q["ohlc"],
        }
    except Exception as e:
        return {"error": str(e)}


# ════════════════════════════════════════════════════════════════════════════
#  UPSTOX  (real-time, requires API key)
# ════════════════════════════════════════════════════════════════════════════

def get_quote_upstox(instrument_key: str) -> dict:
    """
    Fetch live quote via Upstox API v2.

    Steps:
      1. Register at https://developer.upstox.com
      2. Get API key from app dashboard
      3. Auth flow generates access_token via OAuth2
      4. Set UPSTOX_API_KEY env var

    instrument_key format: "NSE_EQ|INE084A01016"  (HDFCBANK example)
    Full instrument list: https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz
    """
    url     = "https://api.upstox.com/v2/market-quote/quotes"
    headers = {
        "Authorization": f"Bearer {UPSTOX_API_KEY}",
        "Accept":        "application/json",
    }
    params = {"instrument_key": instrument_key}
    try:
        r    = requests.get(url, headers=headers, params=params, timeout=8)
        r.raise_for_status()
        data = r.json()["data"]
        key  = list(data.keys())[0]
        q    = data[key]
        return {
            "cmp":    q["last_price"],
            "change": q["net_change"],
            "volume": q["volume"],
        }
    except Exception as e:
        return {"error": str(e)}


# ════════════════════════════════════════════════════════════════════════════
#  ALPHA VANTAGE  (15-min delayed, free key at alphavantage.co)
# ════════════════════════════════════════════════════════════════════════════

def get_quote_alphavantage(symbol: str) -> dict:
    """
    Fetch quote from Alpha Vantage.
    symbol: "BEL.BSE" or "HDFCBANK.BSE"
    Free key at: https://www.alphavantage.co/support/#api-key
    """
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "GLOBAL_QUOTE",
        "symbol":   symbol,
        "apikey":   ALPHAVANTAGE_API_KEY,
    }
    try:
        r    = requests.get(url, params=params, timeout=10)
        r.raise_for_status()
        q    = r.json()["Global Quote"]
        return {
            "cmp":        float(q["05. price"]),
            "change":     float(q["09. change"]),
            "change_pct": float(q["10. change percent"].replace("%","")),
            "volume":     int(q["06. volume"]),
            "52w_high":   float(q["03. high"]),
        }
    except Exception as e:
        return {"error": str(e)}


# ════════════════════════════════════════════════════════════════════════════
#  TECHNICAL INDICATORS  (computed from OHLCV history)
# ════════════════════════════════════════════════════════════════════════════

def compute_technicals(df: pd.DataFrame) -> dict:
    """
    Given a OHLCV DataFrame, compute key technical indicators.
    Returns dict with RSI, SMA50, SMA200, MACD, trend signal.
    """
    if df.empty or len(df) < 20:
        return {}

    close = df["Close"]

    # Simple Moving Averages
    sma50  = close.rolling(50).mean().iloc[-1]  if len(df) >= 50  else None
    sma200 = close.rolling(200).mean().iloc[-1] if len(df) >= 200 else None
    cmp    = close.iloc[-1]

    # RSI (14-period)
    delta  = close.diff()
    gain   = delta.clip(lower=0).rolling(14).mean()
    loss   = (-delta.clip(upper=0)).rolling(14).mean()
    rs     = gain / loss
    rsi    = round((100 - 100 / (1 + rs)).iloc[-1], 1)

    # MACD (12,26,9)
    ema12  = close.ewm(span=12).mean()
    ema26  = close.ewm(span=26).mean()
    macd   = ema12 - ema26
    signal = macd.ewm(span=9).mean()
    macd_cross = "Bullish" if macd.iloc[-1] > signal.iloc[-1] else "Bearish"

    # Volume spike (today vs 20-day avg)
    vol_ratio = round(df["Volume"].iloc[-1] / df["Volume"].rolling(20).mean().iloc[-1], 2) if "Volume" in df else None

    trend = "Bullish" if (sma50 and cmp > sma50) else "Bearish"

    return {
        "cmp":            round(cmp, 2),
        "rsi":            rsi,
        "sma50":          round(sma50, 2) if sma50 else None,
        "sma200":         round(sma200, 2) if sma200 else None,
        "above_50dma":    cmp > sma50 if sma50 else False,
        "above_200dma":   cmp > sma200 if sma200 else False,
        "macd_signal":    macd_cross,
        "volume_ratio":   vol_ratio,
        "trend":          trend,
    }


# ════════════════════════════════════════════════════════════════════════════
#  UNIFIED INTERFACE — called by app.py
# ════════════════════════════════════════════════════════════════════════════

def get_live_quote(symbol: str) -> dict:
    """Main entry point. Uses configured PROVIDER."""
    if PROVIDER == "yahoo":
        return get_quote_yahoo(symbol)
    elif PROVIDER == "zerodha":
        raise NotImplementedError("Pass instrument_token to get_quote_zerodha() directly.")
    elif PROVIDER == "upstox":
        raise NotImplementedError("Pass instrument_key to get_quote_upstox() directly.")
    elif PROVIDER == "alphavantage":
        return get_quote_alphavantage(f"{symbol}.BSE")
    return {}


def get_live_technicals(symbol: str) -> dict:
    """Fetch history and compute technicals for a given NSE symbol."""
    df = get_history_yahoo(symbol, period="1y")
    return compute_technicals(df)


# ── Quick test ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    symbols = ["BEL", "NESTLEIND", "HDFCBANK", "APOLLOHOSP"]
    for sym in symbols:
        q = get_live_quote(sym)
        t = get_live_technicals(sym)
        print(f"\n{sym}:")
        print(f"  CMP: ₹{q.get('cmp')}  Change: {q.get('change_pct')}%")
        print(f"  RSI: {t.get('rsi')}  Above 50DMA: {t.get('above_50dma')}  Trend: {t.get('trend')}")
