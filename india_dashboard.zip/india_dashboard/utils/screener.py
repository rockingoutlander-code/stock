"""
utils/screener.py
=================
Algorithmic screening engine for daily stock picks.

The algorithm runs in 4 steps:
  1. Fundamental filter   — revenue growth, profit growth, ROE, debt, promoter
  2. Technical filter     — DMA crossovers, RSI, volume, breakout pattern
  3. Momentum score       — composite rank vs Nifty relative strength
  4. Catalyst check       — earnings upcoming, order wins, sector rotation

To plug in live screener data:
  - Use Screener.in API (https://www.screener.in/api/company/)
  - Or Tickertape export
  - Or run your own fundamental DB

Currently uses a curated fundamental database.
"""

import pandas as pd
import numpy as np
from utils.data_fetcher import get_live_technicals


# ════════════════════════════════════════════════════════════════════════════
#  FUNDAMENTAL DATABASE
#  Replace values with live Screener.in / Tickertape API calls
# ════════════════════════════════════════════════════════════════════════════

FUNDAMENTAL_DB = {
    "BEL":       {"rev_growth": 16.2, "profit_growth": 20.5, "roe": 22,  "debt_eq": 0.0,  "promoter": 51.1, "ocf": True,  "sector": "Defence"},
    "NESTLEIND": {"rev_growth": 15.0, "profit_growth": 9.1,  "roe": 95,  "debt_eq": 0.0,  "promoter": 62.8, "ocf": True,  "sector": "FMCG"},
    "APOLLOHOSP":{"rev_growth": 12.8, "profit_growth": 26.0, "roe": 13,  "debt_eq": 0.4,  "promoter": 29.3, "ocf": True,  "sector": "Healthcare"},
    "HINDUNILVR":{"rev_growth": 9.2,  "profit_growth": 11.0, "roe": 20,  "debt_eq": 0.0,  "promoter": 61.9, "ocf": True,  "sector": "FMCG"},
    "HDFCBANK":  {"rev_growth": 12.0, "profit_growth": 8.1,  "roe": 16,  "debt_eq": 6.8,  "promoter": 18.9, "ocf": True,  "sector": "Banking"},
    "BAJFINANCE":{"rev_growth": 28.0, "profit_growth": 22.0, "roe": 22,  "debt_eq": 3.4,  "promoter": 54.7, "ocf": True,  "sector": "NBFC"},
    "RELIANCE":  {"rev_growth": 14.0, "profit_growth": 11.0, "roe": 11,  "debt_eq": 0.5,  "promoter": 50.3, "ocf": True,  "sector": "Conglomerate"},
    "INDUSTOWER":{"rev_growth": 11.0, "profit_growth": 15.0, "roe": 18,  "debt_eq": 0.8,  "promoter": 69.0, "ocf": True,  "sector": "Telecom Infra"},
    "PRAJIND":   {"rev_growth": 18.0, "profit_growth": 22.0, "roe": 19,  "debt_eq": 0.1,  "promoter": 30.0, "ocf": True,  "sector": "Clean Energy"},
    "SOUTHBANK": {"rev_growth": 14.0, "profit_growth": 8.0,  "roe": 9,   "debt_eq": 8.0,  "promoter": 0.0,  "ocf": True,  "sector": "Banking"},
    "GRAVITA":   {"rev_growth": 20.0, "profit_growth": 18.0, "roe": 24,  "debt_eq": 0.5,  "promoter": 64.0, "ocf": True,  "sector": "Metals"},
}

# Screening thresholds
THRESHOLDS = {
    "rev_growth_min":    10.0,   # %
    "profit_growth_min": 10.0,   # %
    "roe_min":           12.0,   # %
    "debt_eq_max":       10.0,   # x (banks have higher leverage)
    "promoter_min":      20.0,   # %
    "rsi_min":           35,
    "rsi_max":           75,
}


def fundamental_score(symbol: str) -> dict:
    """Score a stock 0–100 on fundamental quality."""
    f = FUNDAMENTAL_DB.get(symbol)
    if not f:
        return {"score": 0, "pass": False, "details": {}}

    score = 0
    details = {}

    # Revenue growth (0-25)
    if f["rev_growth"] >= 20:   s = 25
    elif f["rev_growth"] >= 15: s = 20
    elif f["rev_growth"] >= 10: s = 15
    else:                        s = 5
    score += s; details["rev_growth"] = s

    # Profit growth (0-25)
    if f["profit_growth"] >= 20:   s = 25
    elif f["profit_growth"] >= 15: s = 20
    elif f["profit_growth"] >= 10: s = 15
    else:                           s = 5
    score += s; details["profit_growth"] = s

    # ROE (0-20)
    if f["roe"] >= 20:   s = 20
    elif f["roe"] >= 15: s = 15
    elif f["roe"] >= 12: s = 10
    else:                 s = 3
    score += s; details["roe"] = s

    # Debt (0-15)
    if f["debt_eq"] == 0:   s = 15
    elif f["debt_eq"] < 0.5: s = 12
    elif f["debt_eq"] < 2:   s = 8
    else:                     s = 3
    score += s; details["debt"] = s

    # Promoter holding (0-15)
    if f["promoter"] >= 55:   s = 15
    elif f["promoter"] >= 40: s = 12
    elif f["promoter"] >= 25: s = 8
    else:                      s = 3
    score += s; details["promoter"] = s

    passes = (
        f["rev_growth"]    >= THRESHOLDS["rev_growth_min"] and
        f["profit_growth"] >= THRESHOLDS["profit_growth_min"] and
        f["roe"]           >= THRESHOLDS["roe_min"]
    )

    return {"score": score, "pass": passes, "details": details, "raw": f}


def technical_score(symbol: str) -> dict:
    """Score a stock 0–100 on technical strength using live data."""
    t = get_live_technicals(symbol)
    if not t:
        return {"score": 50, "pass": True, "details": {}}   # neutral if no data

    score   = 0
    details = {}

    # Above 200 DMA (0-30)
    s = 30 if t.get("above_200dma") else 0
    score += s; details["above_200dma"] = s

    # Above 50 DMA (0-20)
    s = 20 if t.get("above_50dma") else 0
    score += s; details["above_50dma"] = s

    # RSI zone (0-25)
    rsi = t.get("rsi", 50)
    if 45 <= rsi <= 65:   s = 25   # ideal momentum zone
    elif 35 <= rsi < 45:  s = 18   # oversold recovery
    elif 65 < rsi <= 75:  s = 15   # strong but not overbought
    else:                  s = 5   # overbought or very weak
    score += s; details["rsi"] = s

    # MACD (0-15)
    s = 15 if t.get("macd_signal") == "Bullish" else 0
    score += s; details["macd"] = s

    # Volume (0-10)
    vol_ratio = t.get("volume_ratio", 1)
    s = 10 if vol_ratio and vol_ratio >= 1.5 else 5 if vol_ratio and vol_ratio >= 1.0 else 0
    score += s; details["volume"] = s

    passes = (
        t.get("rsi", 50) >= THRESHOLDS["rsi_min"] and
        t.get("rsi", 50) <= THRESHOLDS["rsi_max"]
    )

    return {"score": score, "pass": passes, "details": details, "technicals": t}


def composite_score(symbol: str) -> dict:
    """Combine fundamental + technical into a single composite score."""
    f = fundamental_score(symbol)
    t = technical_score(symbol)

    # Weighted composite: 60% fundamental, 40% technical
    composite = round(f["score"] * 0.6 + t["score"] * 0.4, 1)
    confidence = round(composite / 10, 1)  # out of 10

    return {
        "symbol":           symbol,
        "sector":           FUNDAMENTAL_DB.get(symbol, {}).get("sector", "N/A"),
        "fundamental_score":f["score"],
        "technical_score":  t["score"],
        "composite":        composite,
        "confidence":       min(confidence, 10.0),
        "passes_fund":      f["pass"],
        "passes_tech":      t["pass"],
        "fundamentals":     f.get("raw", {}),
        "technicals":       t.get("technicals", {}),
    }


def run_screener(universe: list = None) -> pd.DataFrame:
    """
    Run the full algorithmic screener on a universe of NSE symbols.
    Returns a sorted DataFrame of top candidates.
    """
    if universe is None:
        universe = list(FUNDAMENTAL_DB.keys())

    results = []
    for sym in universe:
        try:
            s = composite_score(sym)
            if s["passes_fund"]:   # only include fundamental qualifiers
                results.append(s)
        except Exception as e:
            print(f"Error screening {sym}: {e}")

    df = pd.DataFrame(results)
    if df.empty:
        return df
    return df.sort_values("composite", ascending=False).reset_index(drop=True)


# ── Quick test ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Running screener on universe...")
    df = run_screener()
    print(df[["symbol", "sector", "fundamental_score", "technical_score", "composite", "confidence"]].to_string())
